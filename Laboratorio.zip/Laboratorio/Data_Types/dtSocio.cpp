#include "dtSocio.h"

dtSocio::dtSocio(int c, string name){
    this->Ci = c;
    this->name = name;
}
int dtSocio::getCi(){
    this->Ci = Ci;
}
string dtSocio::getName(){
    this->name = name;
}